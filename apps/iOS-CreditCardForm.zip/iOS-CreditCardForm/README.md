# iOS-CreditCardForm
Small credit card form demo app

This is a challange I made a few weeks ago. It's basically an interactive way of filling credit card information.

<p align="center">
  <img src="https://cloud.githubusercontent.com/assets/3007012/20689560/f1d14d0c-b5bd-11e6-97ee-7185827698d8.gif" width="200px">
</p>
